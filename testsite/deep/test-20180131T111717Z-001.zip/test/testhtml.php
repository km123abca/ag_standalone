
<head>
<style>
*
{color:red;}
 .lg{float:left;}
 .lg{width: 33%;}       
		@media(min-width: 992px)
 		{ 
 			.lg{width: 33%;}
       	}
 		@media((min-width: 768px) and (max-width: 991px))
 		{ 
 			.md{width: 50%;}
 		}
 		@media(max-width: 767px)
 		{ 
 			.sm{width: 100%;}
 		}
</style>
</head>


<body>



<f class="lg md sm">Basic Pay   </f>
<DA id="f" class="lg md sm">DA</DA>
<TA id="f" class="lg md sm">TA:</TA>
<DAONTA id="f" class="lg md sm">DA on TA: </DAONTA>
<HRA id="f" class="lg md sm">HRA:    </HRA>
<GPF id="f" class="lg md sm">GPF:   </GPF>



<CGGIS id="f" class="lg md sm">CGGIS:   </CGGIS>
<CGHS id="f" class="lg md sm">CGHS:    </CGHS>
<licence id="f" class="lg md sm">License Fee:    </licence>
<protax id="f" class="lg md sm">Professional Tax:   </protax>
<IT id="f" class="lg md sm">Income Tax:    </IT>


<ITSUR id="f" class="lg md sm">IT Surcharge:    </ITSUR>
<Trvry id="f" class="lg md sm">Total Recovery:    </Trvry>
<netpay id="f" class="lg md sm">Net Pay:    </netpay>
<Tier1 id="f" class="lg md sm">TierI:    </Tier1>






</body>