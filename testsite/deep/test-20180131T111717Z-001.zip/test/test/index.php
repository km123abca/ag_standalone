<head>
<style >
	#fset1{
           position:absolute;
           float:left;
		  }
    #insi
    	{
    	position: relative;
    	float:right;
    	}
</style>
<head>

<body>
<fieldset id="fset11">
	<div id="insi"> This is line one of the experiment</div>
</fieldset>

<fieldset id="fset2">
	<div> holaholaholaholaholaholaholaholahola</div>
</fieldset>
<body>